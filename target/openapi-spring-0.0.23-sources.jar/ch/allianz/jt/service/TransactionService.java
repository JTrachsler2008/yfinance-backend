package ch.allianz.jt.service;
import ch.allianz.jt.entity.Account;
import ch.allianz.jt.entity.Transaction;
import ch.allianz.jt.repository.AccountRepository;
import ch.allianz.jt.repository.TransactionRepository;
import ch.allianz.jt.*;
import ch.allianz.jt.entity.*;
import ch.allianz.jt.repository.*;
import org.springframework.stereotype.*;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class TransactionService {

    private final TransactionRepository transactionRepository;
    private final AccountRepository accountRepository;

    public TransactionService(TransactionRepository transactionRepository,
                              AccountRepository accountRepository) {
        this.transactionRepository = transactionRepository;
        this.accountRepository = accountRepository;
    }

    public Transaction createTransaction(Long accountId, Transaction transaction) {

        Account account = accountRepository.findById(accountId)
                .orElseThrow(() -> new RuntimeException("Account not found"));


        double total = transaction.getPrice() * transaction.getQuantity();

        if ("BUY".equalsIgnoreCase(transaction.getType())) {
            account.setCashAmount(account.getCashAmount() - total);
        } else if ("SELL".equalsIgnoreCase(transaction.getType())) {
            account.setCashAmount(account.getCashAmount() + total);
        }

        transaction.setAccount(account);
        transaction.setTimestamp(LocalDateTime.now());

        return transactionRepository.save(transaction);
    }

    public List<Transaction> getAll() {
        return transactionRepository.findAll();
    }
}