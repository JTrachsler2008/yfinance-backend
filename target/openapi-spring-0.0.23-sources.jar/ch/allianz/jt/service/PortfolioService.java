package ch.allianz.jt.service;

import ch.allianz.jt.repository.PortfolioRepository;
import ch.allianz.jt.entity.Portfolio;
import ch.allianz.jt.entity.User;
import ch.allianz.jt.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PortfolioService {

    private final PortfolioRepository portfolioRepository;
    private final UserRepository userRepository;

    public PortfolioService(PortfolioRepository portfolioRepository,
                            UserRepository userRepository) {
        this.portfolioRepository = portfolioRepository;
        this.userRepository = userRepository;
    }

    public Portfolio createPortfolio(Long userId, Portfolio portfolio) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        portfolio.setUser(user);
        return portfolioRepository.save(portfolio);
    }

    public List<Portfolio> getAll() {
        return portfolioRepository.findAll();
    }
}